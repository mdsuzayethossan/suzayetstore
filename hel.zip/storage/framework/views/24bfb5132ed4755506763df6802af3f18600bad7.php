<?php $__env->startSection('content'); ?>
<!-- Main Wrapper -->
<div class="main-wrapper main-wrapper-email">
    <div class="account-content">
        <a href="job-list.html" class="btn btn-primary apply-btn">Apply Job</a>
        <div class="container">

            <!-- Account Logo -->
            <div class="account-logo">
                <a href="index.html"><img style="width: 80px; height:80px; border-radius:50%; border:5px solid #fbbe32" src="<?php echo e(asset('dashboard_assets/img/logo.jpg')); ?>" alt="Dreamguy's Technologies"></a>
            </div>
            <!-- /Account Logo -->

            <div class="account-box">
                <?php if(session('resent')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                </div>
            <?php endif; ?>
                <div class="account-wrapper">

                    <h3 class="account-title">Verify Your Email Address</h3>
                    <p class="account-subtitle">Before proceeding, please check your email for a verification link. If you did not receive the email,</p>

                    <!-- Account Form -->
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group text-center">
                            <button class="btn btn-primary account-btn" type="submit">click here to request another</button>
                        </div>

                    </form>
                    <!-- /Account Form -->

                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Main Wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\suzayetstore\resources\views\auth\verify.blade.php ENDPATH**/ ?>