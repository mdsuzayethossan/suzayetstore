<?php $__env->startSection('content'); ?>

  <!-- register_section - start
            ================================================== -->
            <section class="register_section section_space">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">

                            <ul class="nav register_tabnav ul_li_center" role="tablist">
                                <li role="presentation">
                                    <?php if(session('customer_name')): ?> <button class="active" data-bs-toggle="tab" data-bs-target="#signin_tab" type="button" role="tab" aria-controls="signin_tab" aria-selected="true">Hi!, <?php echo e(session('customer_name')); ?></button><?php endif; ?>
                                </li>

                            </ul>

                            <div class="register_wrap tab-content text-center">
                                 <h3></h3>
                                <div class="welcome_image mb-3">
                                    <img src="<?php echo e(asset('frontend_assets/images/welcome/welcome.jpg')); ?>" alt="welcome">
                                </div>
                                <a href="<?php echo e(route('signin')); ?>" class="btn btn_primary">Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- register_section - end
            ================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\suzayetstore\resources\views\frontend\verified_welcome.blade.php ENDPATH**/ ?>