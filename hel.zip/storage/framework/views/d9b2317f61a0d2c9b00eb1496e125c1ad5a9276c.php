<?php $__env->startSection('content'); ?>
    <!-- register_section - start
            ================================================== -->
            <section class="register_section section_space">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">

                            <ul class="nav register_tabnav ul_li_center" role="tablist">
                                <li role="presentation">
                                    <button class="active" data-bs-toggle="tab" data-bs-target="#signin_tab" type="button" role="tab" aria-controls="signin_tab" aria-selected="true">Enter your email to get a password reset link</button>
                                </li>

                            </ul>

                            <div class="register_wrap tab-content">
                                <?php if(session('sent_rest_email')): ?>
                                <div class="alert alert-success text-center" role="alert">
                                    <?php echo e(session('sent_rest_email')); ?>

                                  </div>

                                <?php endif; ?>

                                <div class="tab-pane fade show active" id="signin_tab" role="tabpanel">
                                    <form action="<?php echo e(route('customer.forgot.email')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form_item_wrap">
                                            <h3 class="input_title">Email Address*</h3>
                                            <div class="form_item">
                                                <label for="email_input"><i class="fas fa-envelope"></i></label>
                                                <input id="email_input" type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
                                            </div>

                                        </div>

                                        <div class="form_item_wrap text-center p-0">
                                            <button type="submit" class="btn btn_primary">Send</button>
                                        </div>
                                    </form>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- register_section - end
            ================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\suzayetstore\resources\views\frontend\customforgotpass.blade.php ENDPATH**/ ?>